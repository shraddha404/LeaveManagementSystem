<?php
if(mail('ketan404@gmail.com', 'test', 'test 123')){
	echo "mail sent";
}
else{
	echo "mail not sent";
}
?>
