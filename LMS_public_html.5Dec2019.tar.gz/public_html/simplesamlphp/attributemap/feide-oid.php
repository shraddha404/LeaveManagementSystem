<?php

$attributemap = array(
    'mobile'      => 'urn:mace:dir:attribute-def:mobile',
    'displayName' => 'urn:oid:2.16.840.1.113730.3.1.241',
);
