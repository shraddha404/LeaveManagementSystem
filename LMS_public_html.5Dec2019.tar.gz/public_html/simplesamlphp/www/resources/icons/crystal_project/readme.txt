These images are from the Crystal theme, licensed under the GNU LGPL.

See: http://www.everaldo.com/crystal/


Original readme:

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
This copyright and license notice covers the images in this directory.
************************************************************************

TITLE:	Crystal Project Icons
AUTHOR:	Everaldo Coelho
SITE:	http://www.everaldo.com
CONTACT: everaldo@everaldo.com

Copyright (c)  2006-2007  Everaldo Coelho.
