<?php
error_reporting(0);
#$db = 'leaveman_ansysleave'; ## Original our portal database
$db = 'leaveman_ansys';
$db_host = 'localhost';
$db_user = 'leaveman_ansysle';
$db_pass = 'ansysleave123';
$dbh = mysql_connect($db_host, $db_user, $db_pass) or die(mysql_error());
mysql_select_db($db, $dbh);
?>
